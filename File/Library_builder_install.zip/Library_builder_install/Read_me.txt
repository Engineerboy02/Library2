To install
1. Move to documents
2. Unzip
3. Move "Library Set Builder" to desktop
4. Done
